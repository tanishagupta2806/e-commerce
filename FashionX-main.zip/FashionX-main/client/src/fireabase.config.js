// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAMbiiquFsXyEc7h_gfNLB2Jo-p993kcvg",
  authDomain: "bazar-d3cb2.firebaseapp.com",
  projectId: "bazar-d3cb2",
  storageBucket: "bazar-d3cb2.appspot.com",
  messagingSenderId: "290833778260",
  appId: "1:290833778260:web:56aa636d4d6a3a38e48fc1",
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
